package com.example.claims.service;

import com.example.claims.model.Claim;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.*;

@Service
public class ClaimService {
    private final Map<String, Claim> claimsById = new HashMap<>();
    private final ObjectMapper mapper = new ObjectMapper();

    @PostConstruct
    public void load() {
        try {
            InputStream is = new ClassPathResource("mocks/claims.json").getInputStream();
            List<Claim> claims = mapper.readValue(is, new TypeReference<>() {});
            for (Claim c : claims) {
                claimsById.put(c.getId(), c);
            }
        } catch (Exception ex) {
            // Log error and continue with empty claims
            System.err.println("Failed to load claims.json: " + ex.getMessage());
            claimsById.clear();
        }
    }

    public Optional<Claim> getById(String id) {
        return Optional.ofNullable(claimsById.get(id));
    }
}
