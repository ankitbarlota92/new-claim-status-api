# API Testing Guide (Mock Data)

This guide describes how to test the main API endpoints of the Claim Status API locally using only mock data from `src/main/resources/mocks/claims.json` and `src/main/resources/mocks/notes.json`. No Azure OpenAI setup is required.

## Prerequisites
- Java 17 or higher
- Maven
- The application running locally (default port: 8080)

## Start the Application

```bash
mvn clean package && java -jar target/claim-status-api-1.0.0.jar
```

## API Endpoints

### 1. Get Claim by ID
- **Endpoint:** `GET /claims/{id}`
- **Description:** Returns claim data for the given claim ID from mock data.
- **Valid IDs:**
  - `C-1001`
  - `C-1002`
  - `C-1003`
- **Example:**

```bash
curl -X GET "http://localhost:8080/claims/C-1001"
```
- **Example Response:**
```json
{
  "id": "C-1001",
  "policyNumber": "P-9001",
  "customerName": "Alice Janssen",
  "status": "InReview",
  "amount": 1250.5,
  "currency": "EUR",
  "lastUpdated": "2025-10-01T10:00:00Z"
}
```

### 2. Summarize Claim Notes (Mock)
- **Endpoint:** `POST /claims/{id}/summarize`
- **Description:** Returns a mock summary for the given claim ID using notes from mock data.
- **Valid IDs with notes:**
  - `C-1001`
  - `C-1002`
- **Example:**

```bash
curl -X POST "http://localhost:8080/claims/C-1001/summarize"
```
- **Example Notes (from notes.json):**
```
"C-1001": "Wind damage to roof on 24 Sept; photos uploaded. Contractor quote €1,230 plus VAT. Policy covers storm damage; prior claim 2023 resolved. Adjuster called customer on 1 Oct; waiting for final invoice."
```
- **Example Mock Summary Response:**
```json
{
  "summary": "Wind damage to the roof was reported on 24 Sept. Photos and contractor quote submitted. Policy covers storm damage. Adjuster contacted customer; awaiting final invoice.",
  "customerSummary": "Your roof was damaged by wind. We are waiting for the final invoice to proceed.",
  "adjusterSummary": "- Wind damage 24 Sept\n- Photos uploaded\n- Contractor quote €1,230 plus VAT\n- Policy covers storm\n- Prior claim 2023 resolved\n- Adjuster called 1 Oct\n- Awaiting invoice",
  "nextStep": "Obtain and review the final invoice from the contractor."
}
```

## Notes
- Use claim IDs from `claims.json` and `notes.json` (see above for valid IDs).
- The summarize endpoint uses notes from `notes.json` and returns a mock summary response.
- If you receive a 404 error, the claim ID or notes may not exist in the mock data.

## Troubleshooting
- Make sure port 8080 is free (use `lsof -ti tcp:8080 | xargs kill -9` to free it).
- Check logs for errors if the API does not respond as expected.
- Ensure `claims.json` and `notes.json` are present and valid in `src/main/resources/mocks/`.

---
For more details, see the main README or contact the project maintainer.
