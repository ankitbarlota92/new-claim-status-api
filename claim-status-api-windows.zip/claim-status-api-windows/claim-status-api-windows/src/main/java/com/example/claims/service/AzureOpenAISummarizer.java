package com.example.claims.service;

import com.example.claims.model.SummaryResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

@Service
public class AzureOpenAISummarizer {

    @Value("${app.openai.endpoint}")
    private String endpoint;

    @Value("${app.openai.apiKey}")
    private String apiKey;

    @Value("${app.openai.deployment}")
    private String deployment;

    @Value("${app.openai.apiVersion}")
    private String apiVersion;

    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient http = HttpClient.newHttpClient();

    public SummaryResponse summarize(String claimId, String claimNotes) throws Exception {
        if (endpoint == null || endpoint.isBlank() || apiKey == null || apiKey.isBlank() || deployment == null || deployment.isBlank()) {
            // Return mock summary if Azure config is missing
            return new SummaryResponse(
                "Wind damage to the roof was reported on 24 Sept. Photos and contractor quote submitted. Policy covers storm damage. Adjuster contacted customer; awaiting final invoice.",
                "Your roof was damaged by wind. We are waiting for the final invoice to proceed.",
                "- Wind damage 24 Sept\n- Photos uploaded\n- Contractor quote €1,230 plus VAT\n- Policy covers storm\n- Prior claim 2023 resolved\n- Adjuster called 1 Oct\n- Awaiting invoice",
                "Obtain and review the final invoice from the contractor."
            );
        }

        String systemPrompt = """
            You are an assistant that summarizes insurance claim adjuster notes.
            Return STRICT JSON with keys: summary, customerSummary, adjusterSummary, nextStep.
            """;

        String userPrompt = """
            Claim ID: %s
            Adjuster notes:\n%s\n\nRequirements:\n- "summary": 2-4 sentences, neutral tone.\n- "customerSummary": 1-2 simple sentences, no jargon.\n- "adjusterSummary": 3-5 bullet-style lines merged as a paragraph, include key facts, dates, amounts.\n- "nextStep": one actionable recommendation.
            """.formatted(claimId, claimNotes);

        String body = """
            {
              "messages": [
                {"role":"system","content": %s},
                {"role":"user","content": %s}
              ],
              "temperature": 0.3,
              "response_format": {"type":"json_object"}
            }
            """.formatted(jsonString(systemPrompt), jsonString(userPrompt));

        String url = String.format("%s/openai/deployments/%s/chat/completions?api-version=%s", endpoint, deployment, apiVersion);

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .header("api-key", apiKey)
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                .build();

        HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
        if (res.statusCode() >= 300) {
            throw new RuntimeException("Azure OpenAI call failed: " + res.statusCode() + " - " + res.body());
        }

        JsonNode root = mapper.readTree(res.body());
        String content = root.path("choices").get(0).path("message").path("content").asText();
        JsonNode json = mapper.readTree(content);

        return new SummaryResponse(
                json.path("summary").asText(""),
                json.path("customerSummary").asText(""),
                json.path("adjusterSummary").asText(""),
                json.path("nextStep").asText("")
        );
    }

    private String jsonString(String s) throws Exception {
        return mapper.writeValueAsString(s);
    }
}
