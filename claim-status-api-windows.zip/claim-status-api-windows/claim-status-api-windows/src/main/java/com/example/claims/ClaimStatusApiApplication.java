package com.example.claims;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClaimStatusApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(ClaimStatusApiApplication.class, args);
    }
}
