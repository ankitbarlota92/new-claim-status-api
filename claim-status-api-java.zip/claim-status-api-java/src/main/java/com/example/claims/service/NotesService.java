package com.example.claims.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.Map;
import java.util.Optional;

@Service
public class NotesService {
    private Map<String, String> notesById;
    private final ObjectMapper mapper = new ObjectMapper();

    @PostConstruct
    public void load() {
        try {
            InputStream is = new ClassPathResource("mocks/notes.json").getInputStream();
            notesById = mapper.readValue(is, new TypeReference<>() {});
        } catch (Exception ex) {
            throw new RuntimeException("Failed to load notes.json", ex);
        }
    }

    public Optional<String> getNotes(String claimId) {
        return Optional.ofNullable(notesById.get(claimId));
    }
}
