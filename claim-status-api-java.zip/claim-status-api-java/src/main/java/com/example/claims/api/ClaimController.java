package com.example.claims.api;

import com.example.claims.model.SummaryResponse;
import com.example.claims.service.AzureOpenAISummarizer;
import com.example.claims.service.ClaimService;
import com.example.claims.service.NotesService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/claims")
public class ClaimController {

    private final ClaimService claimService;
    private final NotesService notesService;
    private final AzureOpenAISummarizer summarizer;

    public ClaimController(ClaimService claimService, NotesService notesService, AzureOpenAISummarizer summarizer) {
        this.claimService = claimService;
        this.notesService = notesService;
        this.summarizer = summarizer;
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getClaim(@PathVariable String id) {
        return claimService.getById(id)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(Map.of("error", "Claim not found")));
    }

    @PostMapping("/{id}/summarize")
    public ResponseEntity<?> summarize(@PathVariable String id) {
        var claimOpt = claimService.getById(id);
        if (claimOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "Claim not found"));
        }
        var notesOpt = notesService.getNotes(id);
        if (notesOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "Notes not found for claim"));
        }
        try {
            SummaryResponse summary = summarizer.summarize(id, notesOpt.get());
            return ResponseEntity.ok(summary);
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Summarization failed", "details", ex.getMessage()));
        }
    }
}
