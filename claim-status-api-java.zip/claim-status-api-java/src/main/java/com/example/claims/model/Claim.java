package com.example.claims.model;

public class Claim {
    private String id;
    private String policyNumber;
    private String customerName;
    private String status;
    private double amount;
    private String currency;
    private String lastUpdated;

    public Claim() {}

    public Claim(String id, String policyNumber, String customerName, String status, double amount, String currency, String lastUpdated) {
        this.id = id;
        this.policyNumber = policyNumber;
        this.customerName = customerName;
        this.status = status;
        this.amount = amount;
        this.currency = currency;
        this.lastUpdated = lastUpdated;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getPolicyNumber() { return policyNumber; }
    public void setPolicyNumber(String policyNumber) { this.policyNumber = policyNumber; }
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public String getLastUpdated() { return lastUpdated; }
    public void setLastUpdated(String lastUpdated) { this.lastUpdated = lastUpdated; }
}
