# Claim Status API (Java, Spring Boot 3)

This repo implements the lab: ACA + APIM + Azure OpenAI summaries.

## Endpoints
- `GET /claims/{id}` – returns claim status from `mocks/claims.json`
- `POST /claims/{id}/summarize` – reads internal notes from `mocks/notes.json`, calls Azure OpenAI, returns JSON with `summary`, `customerSummary`, `adjusterSummary`, `nextStep`.

## Local run
```bash
export AZURE_OPENAI_ENDPOINT=... \
       AZURE_OPENAI_KEY=... \
       AZURE_OPENAI_DEPLOYMENT=... \
       AZURE_OPENAI_API_VERSION=2024-02-15-preview
mvn package && java -jar target/claim-status-api-1.0.0.jar
```

## Docker
```bash
docker build -t claim-status-api:local .
docker run -p 8080:8080 \
  -e AZURE_OPENAI_ENDPOINT \
  -e AZURE_OPENAI_KEY \
  -e AZURE_OPENAI_DEPLOYMENT \
  -e AZURE_OPENAI_API_VERSION=2024-02-15-preview \
  claim-status-api:local
```

## Deploy
- Use `iac/aca.bicep` + `iac/parameters.json` or Azure CLI.
- Import `apim/openapi.yaml` into APIM and apply `apim/api-policy.xml`.

## CI/CD
- `pipelines/azure-pipelines.yml` builds, optionally scans, pushes to ACR, and deploys to ACA.

## Observability
- KQL queries in `observability/` for APIM and Container Apps logs.
