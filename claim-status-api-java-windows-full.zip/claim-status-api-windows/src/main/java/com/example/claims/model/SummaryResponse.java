package com.example.claims.model;

public class SummaryResponse {
    private String summary;
    private String customerSummary;
    private String adjusterSummary;
    private String nextStep;

    public SummaryResponse() {}
    public SummaryResponse(String summary, String customerSummary, String adjusterSummary, String nextStep) {
        this.summary = summary;
        this.customerSummary = customerSummary;
        this.adjusterSummary = adjusterSummary;
        this.nextStep = nextStep;
    }
    public String getSummary() { return summary; }
    public void setSummary(String summary) { this.summary = summary; }
    public String getCustomerSummary() { return customerSummary; }
    public void setCustomerSummary(String customerSummary) { this.customerSummary = customerSummary; }
    public String getAdjusterSummary() { return adjusterSummary; }
    public void setAdjusterSummary(String adjusterSummary) { this.adjusterSummary = adjusterSummary; }
    public String getNextStep() { return nextStep; }
    public void setNextStep(String nextStep) { this.nextStep = nextStep; }
}
