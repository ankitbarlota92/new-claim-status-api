# Claim Status API (Java, Spring Boot 3) — Windows agent pipeline

Implements two endpoints and deploys to Azure Container Apps. APIM policies, IaC, and observability included.

## Endpoints
- `GET /claims/{id}` — returns claim JSON from `mocks/claims.json`
- `POST /claims/{id}/summarize` — reads internal notes from `mocks/notes.json`, calls Azure OpenAI, returns `{ summary, customerSummary, adjusterSummary, nextStep }`

## Local run
```bash
export AZURE_OPENAI_ENDPOINT=... \
       AZURE_OPENAI_KEY=... \
       AZURE_OPENAI_DEPLOYMENT=... \
       AZURE_OPENAI_API_VERSION=2024-02-15-preview
mvn package && java -jar target/claim-status-api-1.0.0.jar
```

## Pipeline
Use `pipelines/azure-pipelines.yml` — configured for a **Windows self-hosted agent** with Docker + Azure CLI installed.
